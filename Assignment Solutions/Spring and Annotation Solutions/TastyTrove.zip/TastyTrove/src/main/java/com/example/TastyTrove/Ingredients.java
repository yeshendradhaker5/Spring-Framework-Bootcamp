package com.example.TastyTrove;

import java.util.List;

public interface Ingredients {

    void setIngredient(String ingredient);

    String getDishDetail();

    List<String> getIngredientsDetail();
}

