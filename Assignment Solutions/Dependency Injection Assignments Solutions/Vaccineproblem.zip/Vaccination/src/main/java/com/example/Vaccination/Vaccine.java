package com.example.Vaccination;

public interface Vaccine {
        String getType();
}
