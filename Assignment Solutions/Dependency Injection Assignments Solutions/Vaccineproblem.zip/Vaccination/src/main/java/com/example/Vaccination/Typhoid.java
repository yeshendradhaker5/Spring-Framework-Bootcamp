package com.example.Vaccination;

public class Typhoid implements Vaccine {

    @Override
    public String getType(){
        return "Typhoid";
    }
}
