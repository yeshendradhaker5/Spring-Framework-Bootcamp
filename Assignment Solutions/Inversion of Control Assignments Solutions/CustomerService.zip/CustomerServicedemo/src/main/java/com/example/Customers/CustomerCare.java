/**
 * 
 */
package com.example.Customers;

public interface CustomerCare {
	
	String getDepartment();

	void getService();

	void setCustomerName(String name);
	
	void setProblem(String problem); 
	
	void getProblem(); 

}
