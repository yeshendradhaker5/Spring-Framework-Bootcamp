package com.codingNinjas.Bank.Account.Registration;


public interface Account {
    String getAccountType();

    void addBalance(double balance);

    double getBalance();
}
