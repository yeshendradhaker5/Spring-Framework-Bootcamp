package com.example.Cinemaxify;

// Override the User Interface methods in Self class
public class Self{

    private String name;
    private String memberName = "self";
    private int age;
    private Long contact;
    private String address;

}
