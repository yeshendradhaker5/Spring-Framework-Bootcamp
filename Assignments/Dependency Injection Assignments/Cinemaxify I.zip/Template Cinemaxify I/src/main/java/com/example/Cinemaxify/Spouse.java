package com.example.Cinemaxify;

// Override the User Interface methods in Spouse class
public class Spouse{
    private String name;
    private String memberName = "spouse";
    private int age;
    private Long contact;
    private String address;

}
