package com.example.Cinemaxify;

/** Implement the Plan interface and override the getPlanName() method **/
public class NormalPlan {
    private String planName = "normal";


}
