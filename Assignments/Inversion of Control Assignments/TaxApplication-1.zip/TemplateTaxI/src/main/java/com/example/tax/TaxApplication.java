package com.example.tax;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaxApplication {

	public static void main(String[] args) {
		// Take ClassPathXmlApplicationContext from applicationContext.xml file

	}

}
