package com.example.CarServicePart_1.domain;
import org.springframework.stereotype.Component;

@Component
public class Car {

/**

 1. Domain Model is already created for you, just generate getter and setter.
 2. Also,Implement the interface Vehicle and Override the method saveVehicleDetails() and createVehicle() in car.
**/
    String RegisterationNumber;
    String CarName;
    String CarDetails;
    String CarWork;
    Integer CarId;

}
