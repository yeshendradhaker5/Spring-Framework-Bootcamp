package railway.com.example.RailwayAndMeal.Entity;

public class Ticket {

	public long pnr;
	public String name;
	public long age;
	public String birth;

	public Ticket() {
	}

	public Ticket(long pnr, String name, long age, String birth) {
		this.pnr = pnr;
		this.name = name;
		this.age = age;
		this.birth = birth;
	}


	// Generate required getters and setters
	
}
