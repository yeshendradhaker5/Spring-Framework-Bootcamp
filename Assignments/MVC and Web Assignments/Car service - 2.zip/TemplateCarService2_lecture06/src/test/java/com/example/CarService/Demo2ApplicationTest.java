package com.example.CarService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class Demo2ApplicationTest {
    

    @Test
    void contextLoads(){

    }
}
