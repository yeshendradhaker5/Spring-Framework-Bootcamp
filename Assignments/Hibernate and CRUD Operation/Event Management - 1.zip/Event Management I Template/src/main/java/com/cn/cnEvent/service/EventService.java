package com.cn.cnEvent.service;

import org.springframework.stereotype.Service;

@Service
public class EventService {

}
