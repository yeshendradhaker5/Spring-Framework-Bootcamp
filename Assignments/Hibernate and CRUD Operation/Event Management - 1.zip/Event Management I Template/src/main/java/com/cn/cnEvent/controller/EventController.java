package com.cn.cnEvent.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/event")
public class EventController {
}
