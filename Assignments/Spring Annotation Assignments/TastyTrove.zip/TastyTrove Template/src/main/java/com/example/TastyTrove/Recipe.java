package com.example.TastyTrove;

public interface Recipe {

    void getDetails();

    void setUserName(String userName);
}
