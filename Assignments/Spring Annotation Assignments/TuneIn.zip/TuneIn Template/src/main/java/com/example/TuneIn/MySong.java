package com.example.TuneIn;

public class MySong implements Song {
    private String name;

    @Override
    public String getSongName() {
        return this.name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

}
