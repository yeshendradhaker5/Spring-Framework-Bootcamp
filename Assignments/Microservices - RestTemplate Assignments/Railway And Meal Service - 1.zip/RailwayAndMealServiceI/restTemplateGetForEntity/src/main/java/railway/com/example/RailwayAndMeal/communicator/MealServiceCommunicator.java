package railway.com.example.RailwayAndMeal.communicator;

/*
 * 1. Create a method to get the Meal Details from meal service with the help
 * 	   of RestTemplate.
 * 2. Use getForEntity() method from the RestTemplate class.
 * 3. Make use of proper annotations to autowire.
 * 4. Use Postman app to test the APIs.
 */
public class MealServiceCommunicator {
	
	
}
